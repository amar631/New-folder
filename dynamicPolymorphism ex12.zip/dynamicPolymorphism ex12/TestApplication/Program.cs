﻿
using Excercise12;
namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example usage
            Employee employee;

            employee = new SystemsEngineer("C#");
            var finance = new Finance();
            var totalSalary = finance.GetCalculatedSalary(employee);
            Console.WriteLine($"Total Salary (SystemsEngineer - C#): {totalSalary}");

            // Create a Manager
            employee = new Manager();
            totalSalary = finance.GetCalculatedSalary(employee);
            Console.WriteLine($"Total Salary (Manager): {totalSalary}");

            // Create a SeniorProjectManager
            employee = new SeniorProjectManager();
            totalSalary = finance.GetCalculatedSalary(employee);
            Console.WriteLine($"Total Salary (SeniorProjectManager): {totalSalary}");
        }
    }
}
