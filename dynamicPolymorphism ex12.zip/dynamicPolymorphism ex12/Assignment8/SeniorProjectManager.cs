﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise12
{
    public class SeniorProjectManager : Employee
    {
        public decimal CarAllowance { get; private set; }

        public SeniorProjectManager() : base()
        {
            CarAllowance = 6000m;
        }

        public override decimal CalculateSalary()
        {
            return BasicSalary + CarAllowance;
        }
    }
}
