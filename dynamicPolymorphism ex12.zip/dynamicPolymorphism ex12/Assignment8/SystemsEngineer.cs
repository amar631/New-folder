﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise12
{
    public class SystemsEngineer : Employee
    {
        public string Specialization { get; private set; }
        public decimal SpecialistAllowance { get; private set; }

        public SystemsEngineer(string specialization) : base()
        {
            Specialization = specialization;
            SpecialistAllowance = CalculateSpecialistAllowance();
        }

        private decimal CalculateSpecialistAllowance()
        {
            return new string[] { "C#", "Java", "SQL" }.Contains(Specialization) ? 3000m : 0m;
        }

        public override decimal CalculateSalary()
        {
            return BasicSalary + SpecialistAllowance;
        }
    }
}
