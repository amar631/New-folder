﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise12
{
    public class Employee
    {
        public decimal BasicSalary { get; private set; }

        public Employee()
        {
            BasicSalary = 10000m;
        }

        public virtual decimal CalculateSalary()
        {
            return BasicSalary;
        }
    }
}
