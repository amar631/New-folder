﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise12
{
    public class Finance
    {
        public decimal GetCalculatedSalary(Employee employee)
        {
            decimal bonus = 0m;

            if (employee is SystemsEngineer)
            {
                bonus = 5000m;
            }
            else if (employee is Manager)
            {
                bonus = 9000m;
            }
            else if (employee is SeniorProjectManager)
            {
                bonus = 15000m;
            }

            return employee.CalculateSalary() + bonus;
        }
    }
}
