﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise12
{
    public class Manager : Employee
    {
        public decimal PhoneAllowance { get; private set; }

        public Manager() : base()
        {
            PhoneAllowance = 4000m;
        }

        public override decimal CalculateSalary()
        {
            return BasicSalary + PhoneAllowance;
        }
    }
}
