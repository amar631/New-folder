﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineFoodOrderWebService.Models
{
    public class Item
    {
        // To-do: Implement properties with appropriate validations
        [Required]
        public string ItemId { get; set; } = null!;
        [Required]
        [MinLength(4)]
        [MaxLength(50)]
        public string ItemName { get; set; } = null!;
        [Required]
        public int CategoryId { get; set; }
        [Required]
        public decimal Price { get; set; }
    }
}
