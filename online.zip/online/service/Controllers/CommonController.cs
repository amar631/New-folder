﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineFoodOrderDALCrossPlatform;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineFoodOrderWebService.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CommonController : Controller
    {
        CommonRepository repository;
        public CommonController(CommonRepository commonRepository)
        {
            // To-do: Implement necessary code here
            repository = commonRepository;
        }

        #region CheckDeliveryStatus
        [HttpGet]
        public JsonResult CheckDeliveryStatus(int orderId)
        {
            // To-do: Implement necessary code here
            int status = 0;
            string msg = "";
            try
            {
                status = repository.CheckDeliveryStatus(orderId);
                if (status == 1)
                {
                    msg = "Not Delivered";
                }
                else if (status == 0)
                {
                    msg = "Delivered";

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                msg = "error";
            }

            return Json(msg);
        }
        #endregion

        #region DeleteOrderDetails
        [HttpDelete]
        public JsonResult DeleteOrderDetails(int orderId)
        {
            // To-do: Implement necessary code here
            string message = null;
            try
            {
                bool status = repository.DeleteOrderDetails(orderId);
                if (status)
                {
                    message = "Order Cancelled!";
                }
            }
            catch (Exception)
            {
                message = "Some error occured";
            }
            return Json(message);
        }
        #endregion

        #region GetAllOrderDetails
        [HttpGet]
        public JsonResult GetAllOrderDetails(int orderId)
        {
            // To-do: Implement necessary code here

            List<OrderDetails> listorderdetails = new List<OrderDetails>();
            try
            {
                listorderdetails = repository.GetAllOrderDetails(orderId);
            }
            catch (Exception)
            {
                listorderdetails = null;
            }
            return Json(listorderdetails);
        }
        #endregion
    }
}
