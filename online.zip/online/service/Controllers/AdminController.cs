﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineFoodOrderDALCrossPlatform;
using OnlineFoodOrderDALCrossPlatform.Models;
using OnlineFoodOrderWebService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineFoodOrderWebService.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AdminController : Controller
    {
        AdminRepository repository;
        public AdminController(AdminRepository adminRepository)
        {
            // To-do: Implement necessary code here
            repository= adminRepository;
        }
        #region AddItem
        [HttpPost]
        public JsonResult AddItem(Models.Item item)
        {
            // To-do: Implement necessary code here
            bool status = false;
            var message = "";
            try
            {
                string itemid = item.ItemId;
                string itemname = item.ItemName;
                int categoryid = item.CategoryId;
                decimal price = item.Price;
                status = repository.AddItem(itemid, itemname, categoryid, price);
                if (status)
                    message = "Item added successfully!";
                else
                    message = "Error!";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                message = "Error!";
            }
            return Json(message);

        }
        #endregion

        #region GetAllCategoryOrderDetails
        [HttpGet]
        public JsonResult GetAllCategoryOrderDetails(int categoryId)
        {
            
            List<CategoryItemDetails> orderdetails = null;
            try
            {
                orderdetails = repository.GetAllCategoryOrderDetails(categoryId);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                orderdetails = null;
            }
            return Json(orderdetails);




        }
        #endregion

        #region UpdatePrice
        [HttpPut]
        public JsonResult UpdatePrice(string itemId, decimal price)
        {
            // To-do: Implement necessary code here
            var message = "";
            var status = false;
            try
            {
                status = repository.UpdatePrice(itemId, price);
                if (status)
                    message = "Price Updated sucessfully";
                else
                    message = "Unsccussful operation";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                message = "Unsuccesful operation";
            }
            return Json(message);

        }
        #endregion
    }
}
