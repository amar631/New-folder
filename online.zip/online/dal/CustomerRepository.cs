﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OnlineFoodOrderDALCrossPlatform
{
    public class CustomerRepository
    {
        OnlineFoodOrderDBContext context;
        public CustomerRepository(OnlineFoodOrderDBContext onlineFoodOrderDBContext)
        {
            // To-do: Implement necessary code here
            context = onlineFoodOrderDBContext;
        }

        #region GetAllItems
        public List<Item> GetAllItems()
        {
            // To-do: Implement necessary code here
            var itemList = context.Items.ToList();
            return itemList;
        }
        #endregion

        #region GetItemDetails
        public List<ItemDetails> GetItemDetails(string categoryName)
        {
            // To-do: Implement necessary code here
            List<ItemDetails> itemDetails = null;
            try
            {
                //itemDetails = context.Items.Where(c => c.ItemName == categoryName).ToList();
                SqlParameter prmCategoryName = new SqlParameter("@CategoryName", categoryName);
                itemDetails = context.ItemDetails.FromSqlRaw("SELECT * FROM ufn_FetchItemDetails(@CategoryName)",
                                                              prmCategoryName).ToList();
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.StackTrace);
                Console.WriteLine(ex.Message);
                itemDetails = null;
            }
            return itemDetails;
        }
        #endregion

        #region GetItemPrice
        public decimal GetItemPrice(string itemId)
        {
            // To-do: Implement necessary code here
            decimal status;
            try
            {
                status = (from p in context.Items select OnlineFoodOrderDBContext.ufn_FetchItemPrice(itemId)).FirstOrDefault();
            }
            catch (Exception)
            {
                status = 0;
            }

            return status;
        }
        #endregion

        #region PlaceOrder
        public int PlaceOrder(int customerId, string itemId, int quantity,
            string deliveryAddress, DateTime orderDate, out decimal totalPrice,
            out int orderId)
        {
            // To-do: Implement necessary code here
            orderId = 0;
            totalPrice = 0;
            int returnResult = 0;
            int noOfRowsAffected = 0;

            SqlParameter prmCustomerId = new SqlParameter("@CustomerId", customerId);
            SqlParameter prmItemId = new SqlParameter("@ItemId", itemId);
            SqlParameter prmQuantity = new SqlParameter("@Quantity", quantity);
            SqlParameter prmDeliveryAddress = new SqlParameter("@DeliveryAddress", deliveryAddress);
            SqlParameter prmOrderDate = new SqlParameter("@OrederDate", orderDate);
            SqlParameter prmTotalPrice = new SqlParameter("@TotalPrice", System.Data.SqlDbType.Int);
            prmTotalPrice.Direction = System.Data.ParameterDirection.Output;
            SqlParameter prmOredrId = new SqlParameter("@OredrId", System.Data.SqlDbType.Int);
            prmOredrId.Direction = System.Data.ParameterDirection.Output;
            SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
            prmReturnResult.Direction = System.Data.ParameterDirection.Output;

            try
            {
                noOfRowsAffected = context.Database
                         .ExecuteSqlRaw("EXEC @ReturnResult = usp_AddOrderDetails @CustomerId,@ItemId,@Quantity,@DeliveryAddress,@OrederDate, @TotalPrice OUT,@OredrId OUT",
                                        prmReturnResult, prmCustomerId, prmItemId, prmQuantity, prmDeliveryAddress, prmOrderDate, prmTotalPrice, prmOredrId);
                returnResult = Convert.ToInt32(prmReturnResult.Value);
                orderId = Convert.ToInt32(prmOredrId.Value);
                totalPrice = Convert.ToInt32(prmTotalPrice.Value);



            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                Console.WriteLine(ex.Message);
                orderId = 0;
                totalPrice = 0;
                noOfRowsAffected = -1;
                returnResult = -99;


            }


            return returnResult;
        }
        #endregion
    }
}