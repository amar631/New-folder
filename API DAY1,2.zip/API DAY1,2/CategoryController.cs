﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

//using Infosys.QuickKart.Common.Models;
using Microsoft.AspNetCore.Mvc;

namespace Infosys.QuickKart.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CategoryController : Controller
    {
        QuickKartRepository repository;
        public CategoryController(QuickKartRepository repository)
        {
                this.repository = repository;
        }

        [HttpGet]
        public JsonResult GetCategories()
        {
            List<Category> categoriesList = new List<Category>();   
            try
            {

                categoriesList = repository.GetAllCategories();   
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);  
                categoriesList = null;
            }
            return Json(categoriesList);  
        }
        [HttpPost]
        public JsonResult AddCategories(Category category)
        {
            bool status = false;
            string message;

            try
            {
                status = repository.AddCategory(category);
                if (status)
                {
                    message = "Successful addition operation, CategoryName = " + category.CategoryName;
                }
                else
                {
                    message = "Unsuccessful addition operation!";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                message = "Some error occured, please try again!";
            }
            return Json(message);
        }


        [HttpPut]
        public bool Updatecategory(QuickKartServices.Models.Category category)
        {
            bool status = false;

            try
            {
                if (ModelState.IsValid)
                {
                    Category category1 = new Category();
                    
                    category1.CategoryId = category.CategoryId;
                    category1.CategoryName = category.CategoryName;
                    
                    status = repository.UpdateCategory(category1.CategoryId, category1.CategoryName);
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }


        [HttpDelete]
        public JsonResult DeleteCategory(byte categoryId)
        {
            bool status = false;
            try
            {
                status = repository.DeleteCategory(categoryId);
            }
            catch (Exception)
            {
                status = false;
            }
            return Json(status);
        }




    }
}
