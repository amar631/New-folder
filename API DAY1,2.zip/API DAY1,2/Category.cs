﻿using System.ComponentModel.DataAnnotations;

namespace QuickKartServices.Models
{
    public class Category
    {
        [Required]
        public byte CategoryId { get; set; }
        [Required]
        public string CategoryName { get; set; } = null!;
    }
}
