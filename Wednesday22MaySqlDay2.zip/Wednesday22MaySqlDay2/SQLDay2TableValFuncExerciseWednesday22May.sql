﻿CREATE FUNCTION ufn_FetchCustomerPurchases(@Email VARCHAR(50))
RETURNS @Purchases TABLE(PurchaseId BIGINT,DateOfPurchase DATE,ProductName VARCHAR(50),QuantityPurchased SMALLINT,
TotalAmount NUMERIC(8))
AS
BEGIN
INSERT @Purchases
select pr.PurchaseId,pr.DateOfPurchase,p.productName,pr.QuantityPurchased,p.price*pr.QuantityPurchased
from PurchaseDetails pr join Products p on p.ProductId=pr.ProductId WHERE
EmailId=@Email order by dateofpurchase desc
RETURN
END
GO

SELECT * FROM ufn_FetchCustomerPurchases('Pedro@gmail.com')