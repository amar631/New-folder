﻿Create Procedure usp_AddProduct
(
@ProductId char(4),
@ProductName varchar(20),
@CategoryId tinyint,
@Price Numeric,
@QuantityAvailable numeric

--select * from Categories
)
as
Begin
Begin try
begin
if substring(@ProductId,1,1) != 'P' and len(@ProductId) !=4
begin
return -2
end
else if not exists (select CategoryId
from Categories
where CategoryId= @CategoryId)
begin
return -5
end
else if @Price <= 0
begin
return -6
end
else if @QuantityAvailable <= 0
begin
return -7
end

else if @ProductId =null
begin
return -1
end

else if @CategoryId = null
begin
return -4
end
else if @ProductName =null
begin
return -3
end
else
begin tran
Insert into Products(ProductId, ProductName,
CategoryId, Price, QuantityAvailable)
values(@ProductId, @ProductName,
@CategoryId, @Price, @QuantityAvailable)
commit
return 1

end

END TRY

BEGIN CATCH
rollback
return -99
END CATCH
end

declare @ReturnValue Int
exec @ReturnValue= usp_AddProduct 'P981' , 'One Pu Smartphone' , 3, 50000, 5
select @ReturnValue as Result
--select * from Products where ProductId = 'P991'
select * from Products