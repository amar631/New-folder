﻿select *,
ROW_NUMBER() OVER (ORDER BY QuantityAvailable DESC)AS [Row Number],
DENSE_RANK() OVER (ORDER BY QuantityAvailable DESC)AS [Rank] ,
DENSE_RANK() OVER (ORDER BY QuantityAvailable DESC)AS [Dense Rank]

FROM Products