﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineFoodOrderDALCrossPlatform;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineFoodOrderWebService.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CustomerController : Controller
    {
        CustomerRepository repository;
        public CustomerController(CustomerRepository customerRepository)
        {
            // To-do: Implement necessary code here
            repository = customerRepository;
        }


        #region GetAllItems

        [HttpGet]
        public JsonResult GetAllItems()
        {
            // To-do: Implement necessary code here
            List<Item> items = new List<Item>();
            try
            {
                items = repository.GetAllItems();
            }
            catch (Exception)
            {
                items = null;
            }
            return Json(items);
        }
        #endregion

        #region GetAllItemsByCategoryName

        [HttpGet]
        public JsonResult GetAllItemsByCategoryName(string categoryName)
        {
            // To-do: Implement necessary code here

            List<ItemDetails> item = null;
            try
            {
                item = repository.GetItemDetails(categoryName);
            }
            catch (Exception)
            {
                item = null;
            }
            return Json(item);
        }
        #endregion

        #region GetItemPrice 
        [HttpGet]
        public JsonResult GetItemPrice(string itemId)
        {
            // To-do: Implement necessary code here
            //Item item = new Item();
            decimal item;
            try
            {
                item = repository.GetItemPrice(itemId);

            }
            catch (Exception)
            {
                item = 0;

            }

            return Json(item);
        }
        #endregion 

        #region PlaceOrder
        [HttpPost]
        public JsonResult PlaceOrder(Models.Order order)
        {
            //int result =0;
            //String message = String.Empty;
            //try
            //{
            //    result = repository.PlaceOrder(order.CustomerId, order.ItemId, order.Quantity, order.DeliveryAddress, order.OrderDate, out decimal totalPrice, out int orderId);
            //    if (result == 1)
            //    {
            //        message = "Order placed successfully. Your OrderId =" + orderId + "Total Price to be paid =" + totalPrice;
            //    }
            //    else
            //    {
            //        message = "Unsucessful";
            //    }

            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.StackTrace);
            //    message = "Some error occured";
            //}
            //return Json(message);





            // To-do: Implement necessary code here

            String message = null;
            int result = 0;
            try
            {
                result = repository.PlaceOrder(order.CustomerId, order.ItemId, order.Quantity, order.DeliveryAddress, order.OrderDate, out decimal totalPrice, out int orderId);
                if (result == 1)
                {
                    message = "Order placed successfully. Your OrderId =" + orderId + " Total Price to be paid = " + totalPrice;
                }
                else if (result == -1)
                {
                    message = "Customer ID doesn't exist";
                }
                else if (result == -2)
                {
                    message = "Item ID doesn't exist";
                }
                else if (result == -3)
                {
                    message = "Quantity should be grater than zero";
                }
                else if (result == -4)
                {
                    message = "Delivery address should be not null";
                }
                else if (result == -5)
                {
                    message = "The date should not be less than today's date";
                }
                else
                {
                    message = "Some error occured";
                }

            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.StackTrace);
                Console.WriteLine(ex.Message);

                message = "Some error occured";
            }
            return Json(message);





            //int customerId = order.CustomerId;
            //String itemId = order.ItemId;
            //int quantity = order.Quantity;
            //string deliveryAddress = order.DeliveryAddress;
            //DateTime orderDate = order.OrderDate;
            //decimal totalPrice = order.TotalPrice;
            //int orderId =0;             //order.OrderId;
            //int status;
            //string msg = "";
            //try
            //{
            //    status = repository.PlaceOrder(customerId, itemId, quantity, deliveryAddress, orderDate, out totalPrice, out orderId);
            //    if (status == 1)
            //    {
            //        msg = "Order placed successfully. Your OrderId =" + orderId + "Total Price to be paid =" + totalPrice;
            //    }

            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.StackTrace);
            //    status = 0;
            //    msg = "Unsuccessfull";
            //}
            //return Json(msg);



        }
        #endregion
    }
}
