﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineFoodOrderWebService.Models
{
    public class Order
    {
        // To-do: Implement properties with appropriate validations
        public int OrderId { get; set; }

        [Required]
        public int CustomerId { get; set; }
        [Required]
        public String ItemId { get; set; }
        [Required]
        [Range(minimum: 1, maximum: int.MaxValue)]
        public int Quantity { get; set; }
        [Required]
        public decimal TotalPrice { get; set; }
        [Required]
        public string DeliveryAddress { get; set; } = null!;
        [Required]
        public DateTime OrderDate { get; set; }
        public string DeliveryStatus { get; set; } = null!;
    }
}
