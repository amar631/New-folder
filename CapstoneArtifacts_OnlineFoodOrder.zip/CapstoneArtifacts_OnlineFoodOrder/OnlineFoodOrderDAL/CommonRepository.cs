﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OnlineFoodOrderDALCrossPlatform
{
    public class CommonRepository
    {
        OnlineFoodOrderDBContext context;
        public CommonRepository(OnlineFoodOrderDBContext onlineFoodOrderDBContext)
        {
            // To-do: Implement necessary code here
            context = new OnlineFoodOrderDBContext();
        }

        #region CheckDeliveryStatus
        public int CheckDeliveryStatus(int orderId)
        {
            // To-do: Implement necessary code here
            int result;
            try
            {
                result = (from p in context.Orders
                          select OnlineFoodOrderDBContext.ufn_CheckDeliveryStatus(orderId))
                          .FirstOrDefault();
            }
            catch (Exception)
            {
                result = 0;
            }
            return result;
        }
        #endregion

        #region DeleteOrderDetails
        public bool DeleteOrderDetails(int orderId)
        {
            // To-do: Implement necessary code here
            bool status = false;
            Order order = new Order();
            try
            {
                order = context.Orders.Find(orderId);
                context.Orders.Remove(order);
                context.SaveChanges();
                status = true;

            }
            catch (Exception)
            {
                status = false;
            }

            return status;
        }
        #endregion

        #region GetAllOrderDetails
        public List<OrderDetails> GetAllOrderDetails(int orderId)
        {
            // To-do: Implement necessary code here
            List<OrderDetails> orderDetails = null;
            try
            {
                SqlParameter prmOrderId = new SqlParameter("@OrderId", orderId);
                orderDetails = context.OrderDetails.FromSqlRaw("SELECT * FROM ufn_GetOrderDetails(@OrderId)",
                                                        prmOrderId).ToList();

            }
            catch (Exception)
            {
                orderDetails = null;
            }

            return orderDetails;
        }
        #endregion
    }
}
