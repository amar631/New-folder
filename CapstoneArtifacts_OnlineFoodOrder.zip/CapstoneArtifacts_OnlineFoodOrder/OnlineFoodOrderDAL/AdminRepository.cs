﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderDALCrossPlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OnlineFoodOrderDALCrossPlatform
{
    #region Do not modify the signature
    public class AdminRepository
    {
        OnlineFoodOrderDBContext context;
        public AdminRepository(OnlineFoodOrderDBContext onlineFoodOrderDBContext)
        {
            // To-do: Implement necessary code here
            context = new OnlineFoodOrderDBContext();
        }

        #endregion

        #region AddItem
        public bool AddItem(string itemId, string itemName, int categoryId, decimal price)
        {
            // To-do: Implement necessary code here
            bool status = false;
            Item item = new Item();

            try
            {
                item.ItemId = itemId;
                item.ItemName = itemName;
                item.CategoryId = categoryId;
                item.Price = price;


                context.Items.Add(item);
                context.SaveChanges();
                status = true;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                status = false;
            }
            return status;
        }
        #endregion   

        #region GetAllCategoryOrderDetails
        public List<CategoryItemDetails> GetAllCategoryOrderDetails(int categoryId)
        {
            // To-do: Implement necessary code here
            List<CategoryItemDetails> itemDetails = null;
            try
            {
                SqlParameter prmCategoryId = new SqlParameter("@CategoryId", categoryId);
                itemDetails = context.CategoryItemDetails.FromSqlRaw("SELECT * FROM ufn_GetAllOrderDetails(@CategoryId)",
                                                              prmCategoryId).ToList();
            }
            catch (Exception)
            {
                itemDetails = null;
                throw;
            }
            return itemDetails;
        }
        #endregion

        #region UpdatePrice
        public bool UpdatePrice(string itemId, decimal itemPrice)
        {
            // To-do: Implement necessary code here
            bool status = false;
            try
            {
                Item item = context.Items.Find(itemId);
                item.Price = itemPrice;
                context.SaveChanges();
                status = true;

            }
            catch (Exception)
            {
                status = false;
            }

            return status;
        }
        #endregion
    }
}
