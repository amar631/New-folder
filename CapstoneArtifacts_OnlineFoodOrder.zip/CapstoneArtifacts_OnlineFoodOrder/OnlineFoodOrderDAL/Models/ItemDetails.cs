﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace OnlineFoodOrderDALCrossPlatform.Models
{
    public class ItemDetails
    {
        // To-do: Implement appropriate properties

        [Key]
        public string ItemId { get; set; } = null!;
        public string ItemName { get; set; } = null!;
        
        //public int CategoryId { get; set; }

        public decimal Price { get; set; }

    }

}
